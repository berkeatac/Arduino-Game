
#include "Robots.h"

void Go(Robot & myrobot, Robot & robot2, int cells)
{
	myrobot.Move(cells);
	robot2.SetColor(blue);
}

int main ()
{
	int xDog, yDog, xOwner, yOwner;

	GetInput("Please Enter X position of the owner", xOwner);
	if(xOwner <= 0 || xOwner >= 20){
		ShowMessage("X-position of the owner must be greater than 0 and smaller than 20");
		return 0;
	}

	GetInput("Please Enter Y position of the owner", yOwner);
	if(yOwner <= 0 || yOwner >= 20){
		ShowMessage("Y-position of the owner must be greater than 0 and smaller than 20");
		return 0;
	}

	GetInput("Please Enter X position of the dog", xDog);
	if(xDog <= 0 || xDog >= 20){
		ShowMessage("X-position of the dog must be greater than 0 and smaller than 20");
		return 0;
	}
	if(xDog <= xOwner){
		ShowMessage("X-position of the dog must be greater than X-position of the owner");
		return 0;
	}

	GetInput("Please Enter Y position of the dog", yDog);
	if(yDog <= 0 || yDog >= 20){
		ShowMessage("Y-position of the dog must be greater than 0 and smaller than 20");
		return 0;
	}

	Robot Owner(xOwner, yOwner, north);

    Robot Dog(xDog, yDog); //default direction east
	Dog.SetColor(blue);

	Dog.TurnRight();
	Dog.TurnRight();  //Dog Turns West

	Dog.Move(xDog-xOwner+1); //Dog moves to left cell of owner
								//BURDA CARPISIYORLAR EGER AYNI Y 'DE �SELER

	if (yDog > yOwner){ // if dog is up higher
		Dog.TurnRight();
		Dog.TurnRight();
		Dog.TurnRight(); //faces south
		Dog.Move(yDog-yOwner);  //moves next to owner
		Dog.TurnRight();
		Dog.TurnRight(); //faces north

	}
	else if (yDog < yOwner){ //if dog is lower
		Dog.TurnRight(); //dog turns north
		Dog.Move(yOwner-yDog);	//goes next to owner
	}
	//BURALARDA E��TL�KLERE BAKMAK LAZIM

	//BU NOKTADA YANYANALAR
	Owner.Move(20-yOwner); //owner goes to y = 20

	//BURADA OWNER Y DE HAREKET ETTIKTEN SONRA KOPEK Y'DE SONRA X UZERINDE BERABER HAREKET OLABILIR
	if (xOwner > 10){ //if owner is on right
		Owner.TurnRight();
		Owner.TurnRight();
		Owner.TurnRight(); //turn left
		Owner.Move(xOwner-10); // go to x=10
		Owner.TurnRight();   //turn north
	}
	else if (xOwner < 10){
		Owner.TurnRight(); // face right
		Owner.Move(10-xOwner);
		Owner.TurnRight();
		Owner.TurnRight();
		Owner.TurnRight(); // face north
	}
	
	Dog.Move(20-(yOwner));  //dog goes up to cell y=20
							///ARTIK KOPEGIN YERI DEGISTI BU BIR VARIABLE OLABILIR

	if ((xOwner-1) > 9){ // if dog in new position is to  the right of x=9
		Dog.TurnRight();
		Dog.TurnRight();
		Dog.TurnRight(); //dog face left
		Dog.Move((xOwner-1)-9);
		Dog.TurnRight();//dog face north
	}
	else if ((xOwner-1) < 9){ //if dog new pos to the left
		Dog.TurnRight(); // doggy turns right
		Dog.Move(9-(xOwner-1));
		Dog.TurnRight();
		Dog.TurnRight();
		Dog.TurnRight(); // doggy faces north
	}


	return 0;
}


